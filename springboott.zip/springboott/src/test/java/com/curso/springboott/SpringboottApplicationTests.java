package com.curso.springboott;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringboottApplicationTests {

	@Test
	void contextLoads() {
	}

}
