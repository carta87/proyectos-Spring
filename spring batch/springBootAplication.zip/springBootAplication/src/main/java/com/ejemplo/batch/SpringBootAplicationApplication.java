package com.ejemplo.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAplicationApplication.class, args);
	}

}
