package com.batch.ckunk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CkunkApplicationTests {

	@Test
	void contextLoads() {
	}

}
