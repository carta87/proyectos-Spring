package com.batch.ckunk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CkunkApplication {

	public static void main(String[] args) {
		SpringApplication.run(CkunkApplication.class, args);
	}

}
